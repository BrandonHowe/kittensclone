dojo.declare("classes.KGConfig", null, {
    statics: {
        disableWebWorkers: false,
        locales: ["ru","ja", "br", "fr"],
        isEldermass: false
    }
});
